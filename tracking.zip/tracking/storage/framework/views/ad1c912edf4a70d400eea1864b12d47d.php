<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\tracking\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>