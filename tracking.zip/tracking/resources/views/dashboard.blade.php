@extends('layouts.app')

@section('content')
<h2>Dashboard</h2>

@endsection
